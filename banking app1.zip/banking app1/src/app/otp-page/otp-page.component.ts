import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-otp-page',
  templateUrl: './otp-page.component.html',
  styleUrls: ['./otp-page.component.css']
})
export class OtpPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
